1. Please run the build file by using ./build.sh

3. Start the server by running ./server 8080

2. In another terminal window, run the demoScript by using ./demoScript.sh > output.txt

NOTES: 

The demo script assumes the server is running on the same machine on port 8080.

The compiled server file will be in the HTML_Pages folder so that it has access to the web pages

For some reason, accessing an unauthorized file or a malformed request does not work on the server. It does not send anything back.
